# Trabajo-Practico-Integrador-Grupal---Computacion-Aplicada
Integrantes:
- Emanuel Villanueva
- Facundo Bateado
- Romina Camila Mateo
- Federico Stavin

#Descripcion
Informacion de entregables del TP:
- Directorios correspondientes comprimidos en formato .tar.gz
- Script en /opt/scripts/backup_full.sh
- Configuraciones de servidores instalados
- Discos y particiones
- Diagrama topologico 
